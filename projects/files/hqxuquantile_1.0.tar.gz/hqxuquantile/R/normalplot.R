normalplot <-
function(y, label=F,  n=length(y), fac.names=NULL, xlim=c(-2.2, 2.2), main="Normal Plot", ...)
  { # label the most singificant n effects
    m <- length(y)
    x <- seq(0.5/m, 1.0-0.5/m, by=1/m)
    x <-  qnorm(x)
    y <-  sort(y)
    qqplot(x, y, xlab="normal quantiles", ylab="effects",  xlim=xlim, main=main, ...)
    if(is.null(fac.names)) fac.names <-  names(y)
    else fac.names <-  rev( c(fac.names, rep("", length(y)-length(fac.names)) ) )
 
    ord=order(abs(y))
    if(label) for(i in ord[(m-n+1):m]) text(x[i]+.35,y[i], fac.names[i])  
  }

